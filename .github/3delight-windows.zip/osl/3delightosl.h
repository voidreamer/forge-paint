/* This file contains the 3Delight specific extensions to stdosl.h */

closure color outputvariable(
	string name,
	closure color value )
	[[ int builtin = 1 ]];

closure color outputconstant(
	string name )
	[[ int builtin = 1 ]];

closure color hair(
	vector tip,
	float eta,
	color absorption,
	closure color components
	/*
		optionally:
		vector eccentricity
	*/
	) [[ int builtin = 1 ]];

closure color hair_component(
	string name,
	float longitudinal_roughness,
	float azimuthal_roughness,
	float scale_tilt
	) [[ int builtin = 1 ]];

closure color hair2(
	vector tip,
	float eta,
	color absorption,
	float azimuthal_roughness,
	float primary_longitudinal_roughness,
	/* This is scaled by 0.25 for TT and 4.0 for TRT and TRRT. */
	float longitudinal_roughness,
	float scale_tilt,
	color lobe_tint[4]
	/*
		optionally:
		vector eccentricity
	*/
	) [[ int builtin = 1 ]];

/* volume closures */
closure color isotropic(
	) [[ int builtin = 1 ]];

closure color henyey_greenstein(
	float g
	) [[ int builtin = 1 ]];

closure color absorption(
	) [[ int builtin = 1 ]];


/*
	Unless noted otherwise, the arrays accept up to 6 values.

	interpolations values
	0 : constant
	1 : linear with next point
	2 : smoothstep with next point

	optional parameters:
	closure color specular
	color specularcolor
	float specularalpha
	string[] auxiliaryoutputs (up to 8 values)
	color[] auxiliarycolors (up to 8*6 values)
*/
closure color quantize(
	closure color input,
	float knots[],
	color colors[],
	int interpolations[]
	) [[ int builtin = 1 ]];

/*
	optional parameters:
	float shadowopacity
	color shadowcolor
	string shadowmaskoutput
*/
closure color shadow_matte(
	closure color input ) [[ int builtin = 1 ]];

/*
	optional parameters:
	float distance
*/
closure color occlusion(
	normal N
	) [[ int builtin = 1 ]];

/*
	Layers top above bottom, reducing the contribution of bottom as required to
	conserve energy.

	top_mask is an energy conserving scale on the contribution of top which
	increases the contribution of bottom accordingly.
*/
closure color layer_closures(
	closure color top,
	closure color bottom,
	color top_mask
	) [[ int builtin = 1 ]];
