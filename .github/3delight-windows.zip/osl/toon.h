#pragma once

int
WritableAOVs()
{
	int writable_aovs = 0;
	getattribute("outputvariables:writable", writable_aovs);
	return writable_aovs;
}

int
ToonLayer()
{
	int layer = 0;
	getattribute("toon:layer", layer);
	return layer;
}
