#pragma once

#include "dlInterface.h"
#include <string.h>


struct DlSceneInfo
{
	int m_version{1};

	/* For now, only pixel area (xres * yres * num cameras) */
	int m_pixel_area;
};

struct DlCollectivePair
{
	static const int kMaxNameLength = 100;

	DlCollectivePair() {}

	DlCollectivePair( const char *i_name, int i_cores )
	:
		cores(i_cores)
	{
		::strncpy( name, i_name, kMaxNameLength );
	}

	char name[ kMaxNameLength ] = {0};
	int cores{0};
};

struct DlProcessingInfo
{
	/*
		This is both for the number of collectives and the numbr of machines in
		one collective.
	*/
	static const int kMaxCollectivePairs = 200;

	enum Speed
	{
		e_econo,
		e_normal,
		e_fast,
		e_ludicrous
	};

	int m_version{1};

	/* = true if this is a free version library */
	int m_free{false};

	/* = true if clamped by spending rate */
	int m_clamped{false};

	/*= true if user has logged-in */
	int m_logged_in{false};

	/**
		number of cores on this computer, including multi-threading.
		This will be capped for free license.
	*/
	int m_num_local_threads{0};

	/* Number of cores used for batch renders */
	int m_batch_cores{128};

	/* Number of cores used for Preview renders. */
	int m_interactive_cores{16};
};

extern "C" {
/* Do not delete the returned structure. It is permanent. */
DL_INTERFACE const DlProcessingInfo *DlGetProcessingInfo(
	const DlSceneInfo &i_scene_info, DlProcessingInfo::Speed i_speed );

DL_INTERFACE int DlGetCollectives(
	DlCollectivePair o_collectives[DlProcessingInfo::kMaxCollectivePairs] );

DL_INTERFACE int DlGetCollectiveNodes(
	const char *i_collective,
	DlCollectivePair o_nodes[DlProcessingInfo::kMaxCollectivePairs] );

/* Signs-in a user to the 3Delight Cloud.  Returns true when successful. */
DL_INTERFACE bool DlSignInToCloud();
/* Displays a GUI that allows the user to edit their processing preferences. */
DL_INTERFACE void DlShowProcessingPreferences();

/* Returns true if rendering is set to use 3Delight Cloud. */
DL_INTERFACE bool DlIsRenderUsingCloud();

}
