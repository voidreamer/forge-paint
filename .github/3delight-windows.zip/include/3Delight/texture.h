/******************************************************************************/
/*                                                                            */
/*    Copyright (c)The 3Delight Developers.                                   */
/*    All Rights Reserved.                                                    */
/*                                                                            */
/******************************************************************************/

#ifndef _3delight_texture_h
#define _3delight_texture_h

#include "dlInterface.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
	A convenient function to sample a TDL texture.
*/
DL_INTERFACE int DlTextureLookup(
	const char * i_fileName,
	int i_nPoints,
	int i_nChannels,
	const float *i_s0,
	const float *i_t0,
	const float *i_s1,
	const float *i_t1,
	const float *i_s2,
	const float *i_t2,
	const float *i_s3,
	const float *i_t3,
	float *o_result );

/*
	Fast copy of a texture with the option of downscaling by skipping the
	largest mipmaps.
*/
DL_INTERFACE bool DlCopyTexture(
	const char *i_source_path,
	const char *i_destinatin_path,
	int i_mipmaps_to_skip );

#ifdef __cplusplus
}
#endif

#endif
