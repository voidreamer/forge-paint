#ifndef Feedback_h
#define Feedback_h

#include "dlInterface.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
	This controls the service which receives feedback from 3Delight Display.

	There should be only one handler per running host application so that's all
	the API supports.
*/

/* The callback invoked for every feedback message. */
typedef void (*FeedbackProc)(void *userdata, const char *message);

/* Set the handler. */
DL_INTERFACE void DlFeedbackSetHandler(
	FeedbackProc proc,
	void *userdata);
/* Remove the handler. */
DL_INTERFACE void DlFeedbackRemoveHandler();
/* Get an ID to give to the display for the feedback service. */
DL_INTERFACE const char* DlFeedbackGetID();

#ifdef __cplusplus
}
#endif

#endif
