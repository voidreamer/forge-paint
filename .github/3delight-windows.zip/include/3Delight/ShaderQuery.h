#ifndef __ShaderQuery_h
#define __ShaderQuery_h

#include "dlInterface.h"
#include "nsi.h"

#include <cstddef>
#include <cstring>
#include <string>

/*
	This is very much a clone of OSL::OSLQuery (which is what it calls
	internally) but without the need to link directly with OSL and without the
	potential problems of passing C++ standard library objects through a
	library boundary.

	OSL::TypeDesc is also replaced by a simpler structure which only represents
	what is actually used by shaders.
*/
class DlShaderInfo
{
public:
	/* A most basic C++ container for a constant sequence of objects. */
	template<typename T> class constvector
	{
	public:
		constvector()
			: m_begin(nullptr), m_end(nullptr) {}

		constvector(const T *begin, const T *end)
			: m_begin(begin), m_end(end) {}

		typedef T value_type;
		typedef const T &reference;
		typedef const T* iterator;
		typedef const T* const_iterator;
		typedef std::ptrdiff_t difference_type;
		typedef std::size_t size_type;

		iterator begin() const { return m_begin; }
		iterator end() const { return m_end; }
		const_iterator cbegin() const { return m_begin; }
		const_iterator cend() const { return m_end; }

		bool empty() const { return m_begin == m_end; }
		size_type size() const { return m_end - m_begin; }
		const T* data() const { return m_begin; }

		const T& operator[](std::size_t i) const { return m_begin[i]; }

	private:
		const T *m_begin, *m_end;
	};

	class conststring : public constvector<char>
	{
	public:
		conststring(const char *s = "")
			: constvector<char>(s, s + std::strlen(s)) {}
		/*
			The input sequence should contain the trailing null. We remove 1
			from the end so our sequence does not and size() is right. But it
			is still there for c_str() of course.
		*/
		conststring(const char *begin, const char *end)
			: constvector<char>(begin, end - 1) {}

		const char* c_str() const { return data(); }
		std::string string() const { return std::string(begin(), end()); }

		bool operator==(const char *s) const
			{ return 0 == std::strcmp(c_str(), s); }
		bool operator!=(const char *s) const { return !operator==(s); }

		bool operator==(const std::string &s) const
			{ return *this == s.c_str(); }
		bool operator!=(const std::string &s) const
			{ return *this != s.c_str(); }

		bool operator<(const conststring &rhs) const
			{ return std::strcmp(c_str(), rhs.c_str()) < 0; }
	};

	struct TypeDesc
	{
		/* NSIType_t */
		int elementtype;
		/* Like OSL: 0 = not an array, -1 for unsized array, >0 array length. */
		int arraylen;

		TypeDesc getelementtype() const
			{ TypeDesc t(*this); t.arraylen = 0; return t; }

		std::size_t elementsize() const { return NSITypeSizeOf(elementtype); }

		bool is_array() const { return arraylen != 0; }

		bool operator==(const TypeDesc &t) const
			{ return elementtype == t.elementtype && arraylen == t.arraylen; }
		bool operator!=(const TypeDesc &t) const { return !(*this == t); }

		/* Members to quickly test for common types. */
		bool IsOneFloat() const
			{ return elementtype == NSITypeFloat && arraylen == 0; }
		bool IsOneInteger() const
			{ return elementtype == NSITypeInteger && arraylen == 0; }
		bool IsOneString() const
			{ return elementtype == NSITypeString && arraylen == 0; }
		bool IsOneColor() const
			{ return elementtype == NSITypeColor && arraylen == 0; }
		bool IsOnePoint() const
			{ return elementtype == NSITypePoint && arraylen == 0; }
		bool IsOneVector() const
			{ return elementtype == NSITypeVector && arraylen == 0; }
		bool IsOneNormal() const
			{ return elementtype == NSITypeNormal && arraylen == 0; }
		bool IsOneMatrix() const
			{ return elementtype == NSITypeMatrix && arraylen == 0; }

		bool IsFloatArray() const
			{ return elementtype == NSITypeFloat && arraylen != 0; }
		bool IsIntegerArray() const
			{ return elementtype == NSITypeInteger && arraylen != 0; }
		bool IsStringArray() const
			{ return elementtype == NSITypeString && arraylen != 0; }
		bool IsColorArray() const
			{ return elementtype == NSITypeColor && arraylen != 0; }
		bool IsPointArray() const
			{ return elementtype == NSITypePoint && arraylen != 0; }
		bool IsVectorArray() const
			{ return elementtype == NSITypeVector && arraylen != 0; }
		bool IsNormalArray() const
			{ return elementtype == NSITypeNormal && arraylen != 0; }
		bool IsMatrixArray() const
			{ return elementtype == NSITypeMatrix && arraylen != 0; }
	};

	struct Parameter
	{
		conststring name;
		TypeDesc type;
		bool isoutput;
		bool validdefault;
		bool varlenarray;
		bool isstruct;
		bool isclosure;
		constvector<int> idefault;
		constvector<float> fdefault;
		constvector<conststring> sdefault;
		constvector<conststring> spacename;

		constvector<conststring> fields;
		conststring structname;
		constvector<Parameter> metadata;

		/* This replaces the 'data' member to make copying easier. */
		const void* data() const
		{
			if( !idefault.empty() ) return idefault.data();
			if( !fdefault.empty() ) return fdefault.data();
			if( !sdefault.empty() ) return sdefault.data();
			return nullptr;
		}
	};

	DlShaderInfo() = default;

	DlShaderInfo(
		conststring shadername,
		conststring shadertypename,
		const constvector<Parameter> &params,
		const constvector<Parameter> &meta)
		: m_shadername(shadername), m_shadertypename(shadertypename),
		  m_params(params), m_meta(meta) {}

	const conststring shadertype() const { return m_shadertypename; }
	const conststring shadername() const { return m_shadername; }

	std::size_t nparams() const { return m_params.size(); }

	const Parameter *getparam(std::size_t i) const { return &m_params[i]; }

	const constvector<Parameter>& params() const { return m_params; }
	const constvector<Parameter>& metadata() const { return m_meta; }

private:
	conststring m_shadername;
	conststring m_shadertypename;
	constvector<Parameter> m_params;
	constvector<Parameter> m_meta;
};

extern "C" {
/* Do not delete the returned structure. It is permanent. */
DL_INTERFACE DlShaderInfo* DlGetShaderInfo(
	const char *i_path );

DL_INTERFACE DlShaderInfo* DlGetMemoryShaderInfo(
	const char *i_compiled_shader, size_t i_shader_size );
}

#endif
