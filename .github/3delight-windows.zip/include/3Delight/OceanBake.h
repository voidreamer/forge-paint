#ifndef __OceanBake_h
#define __OceanBake_h

#include <nsi.h>

class DlOceanEvaluator
{
public:
	enum { kCurrentVersion = 3 };

	unsigned m_version{kCurrentVersion};
	unsigned m_max_evaluation_size{1};

	virtual void GetInputBuffers(
		float **position,
		float **positionfilterwidth) = 0;

	virtual void Evaluate(
		unsigned evaluation_size,
		const float **displacement_vector,
		const float **cusp) = 0;
};

extern "C"
{
DL_INTERFACE bool DlBakeOcean(
	DlOceanEvaluator &evaluator,
	const char *bake_target,
	NSIContext_t camera,
	double min_camera_distance,
	double frustum_importance,
	const double plane_size[2],
	const double plane_center[3],
	unsigned bake_resolution,
	bool bake_cusp);
}

#endif
