#ifndef __3DelightProgress_h
#define __3DelightProgress_h

#include <nsi.h>

namespace NSI
{
class ProgressCallback
{
public:
	enum { kCurrentVersion = 1 };
	unsigned m_version{kCurrentVersion};

	struct Value
	{
		/* Overall progress ratio, from 0 to 1.0. */
		double m_render_progress;
		/* Number of seconds we've been rendering (excluding init). */
		double m_seconds_rendering;
		/* Number of completed rendering passes. */
		unsigned m_completed_passes;
		/* Total number of rendering passes. */
		unsigned m_total_passes;
	};

	virtual void Update(NSIContext_t ctx, const Value &progress) = 0;
};
}

#endif
