#ifndef __Cryptomatte_H
#define __Cryptomatte_H

#include <nsi.hpp>

/*
	Utility functions to make the export of Cryptomatte-encoded NSI output
	layers less tedious and verbose.

	The functions are inline in order to avoid problems related to objects
	allocation and deallocation not occuring within the same dynamic library.

*/
namespace DlCryptomatte
{

/*
	Adjusts the attributes of an NSI output layer so it displays a Cryptomatte
	header image (meant for human viewing).

	This simply completes a regular output layer that would have been created as
	part of regular scene export.
*/
inline void SetHeaderNSILayersAttributes(
	NSI::Context& ctx,
	const std::string& handle)
{
	ctx.SetAttribute(
		handle,
		(
			NSI::StringArg("layertype", "color"),
			NSI::IntegerArg("withalpha", 0),
			NSI::IntegerArg("cryptomatte.enable", 1),
			NSI::IntegerArg("cryptomatte.level", -1)
		) );
}


/*
	Creates a set of NSI output layers containing levels of Cryptomatte IDs.

	The handles of newly creates layers are stored in a vector so the caller
	could connect them properly and, eventually, delete them.
*/
inline void ExportExtraNSILayers(
	NSI::Context& ctx,
	const std::string& handle_prefix,
	const std::string& variablename,
	const std::string& variablesource,
	const std::string& filter,
	double filterwidth,
	int& sortkey,
	int nlevels,
	std::vector<std::string>& o_layer_handles)
{
	/*
		Export one additional layer per Cryptomatte level. Each will
		output 2 values from those present in each pixel's samples.
	*/
	for(int c = 0; c < nlevels; c++)
	{
		std::string handle = handle_prefix + std::to_string(c).c_str();

		ctx.Create(handle, "outputlayer");
		ctx.SetAttribute(
			handle,
			(
				NSI::StringArg("variablename", variablename),
				NSI::StringArg("variablesource", variablesource),
				NSI::StringArg("filter", filter),
				NSI::DoubleArg("filterwidth", filterwidth),
				NSI::StringArg("layertype", "quad"),
				NSI::StringArg("scalarformat", "float"),
				NSI::IntegerArg("withalpha", 0),
				NSI::IntegerArg("sortkey", sortkey++),
				NSI::IntegerArg("cryptomatte.enable", 1),
				NSI::IntegerArg("cryptomatte.level", 2*c)
			) );

		o_layer_handles.push_back(handle);
	}
}

}

#endif
