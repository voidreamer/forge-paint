#ifndef __nsicallbacks_h
#define __nsicallbacks_h

#include "nsi.h"

#ifndef __cplusplus
#	include <stdbool.h>
#endif

#define NSI_CALLBACKS_VERSION 1

/**
	\brief callbacks provide a way to trap NSI calls in a give NSI stream.

	Pass in your callbacks to NSIBegin(). Return true if you want the execution
	to continue in the original context, false otherwise.

	Each call will provide you with the nsicallbacks struct you passed to
	NSIBegin. This allows you to append your variables at the end of an
	extended struct.

	The proper way to initialize this is:

	struct nsicallbacks cb;
	memset(&cb, 0, sizeof(nsicallbacks));
	cb.version = NSI_CALLBACKS_VERSION;
*/
struct nsicallbacks
{
	int version;

	bool (*Create)(
		const struct nsicallbacks *,
		NSIHandle_t handle,
		const char *type,
		int nparams,
		const struct NSIParam_t *params );

	bool (*Delete)(
		const struct nsicallbacks *,
		NSIHandle_t handle,
		int nparams,
		const struct NSIParam_t *params );

	bool (*SetAttribute)(
		const struct nsicallbacks *,
		NSIHandle_t object,
		int nparams,
		const struct NSIParam_t *params );

	bool (*SetAttributeAtTime)(
		const struct nsicallbacks *,
		NSIHandle_t object,
		double time,
		int nparams,
		const struct NSIParam_t *params );

	bool (*DeleteAttribute)(
		const struct nsicallbacks *,
		NSIHandle_t object,
		const char *name );

	bool (*Connect)(
		const struct nsicallbacks *,
		NSIHandle_t from,
		const char *from_attr,
		NSIHandle_t to,
		const char *to_attr,
		int nparams,
		const struct NSIParam_t *params );

	bool (*Disconnect)(
		const struct nsicallbacks *,
		NSIHandle_t from,
		const char *from_attr,
		NSIHandle_t to,
		const char *to_attr );

	bool (*Evaluate)(
		const struct nsicallbacks *,
		int nparams,
		const struct NSIParam_t *params );

	bool (*RenderControl)(
		const struct nsicallbacks *,
		int nparams,
		const struct NSIParam_t *params );

	bool (*End)(
		const struct nsicallbacks * );

};

#endif
