#ifndef __nsicallbacks_hpp
#define __nsicallbacks_hpp

#include "nsicallbacks.h"

#include <cstring>

namespace NSI
{

/*
	C++ wrapper around the NSI callbacks.
*/
class Callbacks : private nsicallbacks
{
protected:
	Callbacks()
	{
		std::memset(static_cast<nsicallbacks*>(this), 0, sizeof(nsicallbacks));
		version = NSI_CALLBACKS_VERSION;

		nsicallbacks::Create = BindCreate;
		nsicallbacks::Delete = BindDelete;
		nsicallbacks::SetAttribute = BindSetAttribute;
		nsicallbacks::SetAttributeAtTime = BindSetAttributeAtTime;
		nsicallbacks::DeleteAttribute = BindDeleteAttribute;
		nsicallbacks::Connect = BindConnect;
		nsicallbacks::Disconnect = BindDisconnect;
		nsicallbacks::Evaluate = BindEvaluate;
		nsicallbacks::RenderControl = BindRenderControl;
		nsicallbacks::End = BindEnd;
	}

public:
	/*
		The return value is the pointer which must be given to NSIBegin() as
		the "callbacks" argument.
	*/
	const nsicallbacks* GetCallbacks() const { return this; }

private:

	virtual bool Create(
		NSIHandle_t handle,
		const char *type,
		int nparams,
		const struct NSIParam_t *params)
	{
		return true;
	}
	virtual bool Delete(
		NSIHandle_t handle,
		int nparams,
		const struct NSIParam_t *params)
	{
		return true;
	}
	virtual bool SetAttribute(
		NSIHandle_t object,
		int nparams,
		const struct NSIParam_t *params)
	{
		return true;
	}
	virtual bool SetAttributeAtTime(
		NSIHandle_t object,
		double time,
		int nparams,
		const struct NSIParam_t *params)
	{
		return true;
	}
	virtual bool DeleteAttribute(
		NSIHandle_t object,
		const char *name)
	{
		return true;
	}
	virtual bool Connect(
		NSIHandle_t from,
		const char *from_attr,
		NSIHandle_t to,
		const char *to_attr,
		int nparams,
		const struct NSIParam_t *params)
	{
		return true;
	}
	virtual bool Disconnect(
		NSIHandle_t from,
		const char *from_attr,
		NSIHandle_t to,
		const char *to_attr)
	{
		return true;
	}
	virtual bool Evaluate(
		int nparams,
		const struct NSIParam_t *params)
	{
		return true;
	}
	virtual bool RenderControl(
		int nparams,
		const struct NSIParam_t *params)
	{
		return true;
	}
	virtual bool End()
	{
		return true;
	}

	static bool BindCreate(
		const struct nsicallbacks *cb,
		NSIHandle_t handle,
		const char *type,
		int nparams,
		const struct NSIParam_t *params)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->Create(handle, type, nparams, params);
	}
	static bool BindDelete(
		const struct nsicallbacks *cb,
		NSIHandle_t handle,
		int nparams,
		const struct NSIParam_t *params)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->Delete(handle, nparams, params);
	}
	static bool BindSetAttribute(
		const struct nsicallbacks *cb,
		NSIHandle_t object,
		int nparams,
		const struct NSIParam_t *params)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->SetAttribute(object, nparams, params);
	}
	static bool BindSetAttributeAtTime(
		const struct nsicallbacks *cb,
		NSIHandle_t object,
		double time,
		int nparams,
		const struct NSIParam_t *params)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->SetAttributeAtTime(object, time, nparams, params);
	}
	static bool BindDeleteAttribute(
		const struct nsicallbacks *cb,
		NSIHandle_t object,
		const char *name)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->DeleteAttribute(object, name);
	}
	static bool BindConnect(
		const struct nsicallbacks *cb,
		NSIHandle_t from,
		const char *from_attr,
		NSIHandle_t to,
		const char *to_attr,
		int nparams,
		const struct NSIParam_t *params)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->Connect(from, from_attr, to, to_attr, nparams, params);
	}
	static bool BindDisconnect(
		const struct nsicallbacks *cb,
		NSIHandle_t from,
		const char *from_attr,
		NSIHandle_t to,
		const char *to_attr)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->Disconnect(from, from_attr, to, to_attr);
	}
	static bool BindEvaluate(
		const struct nsicallbacks *cb,
		int nparams,
		const struct NSIParam_t *params)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->Evaluate(nparams, params);
	}
	static bool BindRenderControl(
		const struct nsicallbacks *cb,
		int nparams,
		const struct NSIParam_t *params)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->RenderControl(nparams, params);
	}
	static bool BindEnd(const struct nsicallbacks *cb)
	{
		return const_cast<Callbacks*>(static_cast<const Callbacks*>(cb))
			->End();
	};
};

}

#endif
