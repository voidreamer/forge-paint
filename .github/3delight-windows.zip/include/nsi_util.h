#ifndef __nsi_util_h
#define __nsi_util_h

#include "nsi.h"

#ifdef  __cplusplus
extern "C" {
#endif

DL_INTERFACE void NSIParseTypeString(
	const char *type_string,
	NSIParam_t *result );

DL_INTERFACE int NSITypeToString(
	const NSIParam_t *type,
	unsigned result_length,
	char *result );

/*
	Resolves environment variables in a file path and converts it to an absolute
	path if it's relative.
	Returns a permanently allocated string that shouldn't be freed or modified.
*/
DL_INTERFACE const char* NSIResolveFilePath(
	NSIContext_t ctx,
	const char* path);

/*
	Cache a file locally using the network cache, if required.
	Returns a permanent string with the new path or the input string if no
	caching was done.
*/
DL_INTERFACE const char* NSICacheFile(
	NSIContext_t ctx,
	const char *path);

#ifdef __cplusplus
}

#include <string>

namespace NSI
{

inline const NSIParam_t* FindParameter(
	const std::string& name,
	int type,
	int nparams,
	const struct NSIParam_t* params)
{
	for(int p = 0; p < nparams; p++)
	{
		if(params[p].type == type && params[p].name == name)
		{
			return &params[p];
		}
	}
	return 0;
}

template<typename CType, int NSIType>
inline const CType* FindSingleParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	const NSIParam_t* p = FindParameter(name, NSIType, nparams, params);
	return p && p->count > 0 ? (const CType*)p->data : 0;
}

inline const float* FindFloatParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<float, NSITypeFloat>(name, nparams, params);
}

inline const double* FindDoubleParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<double, NSITypeDouble>(name, nparams, params);
}

inline const int* FindIntegerParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<int, NSITypeInteger>(name, nparams, params);
}

inline const char* FindStringParameter(
	const std::string& name,
	int nparams,
	const struct NSIParam_t* params)
{
	const char* const* s =
		FindSingleParameter<const char*, NSITypeString>(name, nparams, params);
	return s ? *s : 0;
}

inline const float* FindColorParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<float, NSITypeColor>(name, nparams, params);
}

inline const float* FindPointParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<float, NSITypePoint>(name, nparams, params);
}

inline const float* FindVectorParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<float, NSITypeVector>(name, nparams, params);
}

inline const float* FindNormalParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<float, NSITypeNormal>(name, nparams, params);
}

inline const float* FindMatrixParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<float, NSITypeMatrix>(name, nparams, params);
}

inline const double* FindDoubleMatrixParameter(
	const std::string& name, int nparams, const struct NSIParam_t* params)
{
	return FindSingleParameter<double, NSITypeDoubleMatrix>(name, nparams, params);
}

}

#endif

#endif

