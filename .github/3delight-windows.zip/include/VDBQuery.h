#ifndef __VDBQuery_h
#define __VDBQuery_h

#include "dlInterface.h"

#include "stddef.h"

#ifdef  __cplusplus
extern "C" {
#endif

/*
	This returns the world space bounding box of the given file. It is written
	to bbox as: xmin ymin zmin xmax ymax zmax
*/
DL_INTERFACE bool DlVDBGetFileBBox(
	const char *filename,
	double *bbox );

DL_INTERFACE bool DlVDBGetGridNames(
	const char *filename,
	int *num_grids,
	const char *const **grid_names );

DL_INTERFACE void DlVDBFreeGridNames(
	const char *const *grid_names );

/*
	*num_points is set to the number of generated points
	*points is set to an array of *num_points * 3 float values, with
	x0,y0,z0,x1,y1,z1, etc.
*/
DL_INTERFACE void DlVDBGeneratePoints(
	const char *filename,
	const char *densitygrid,
	size_t *num_points,
	const float **points);

/*
	Use this to free the array returned by DlVDBGeneratePoints() in *points.
*/
DL_INTERFACE void DlVDBFreePoints(
	const float *points);

/*
	points is an array of num_points * 3 float values, as provided by
	DlVDBGeneratePoints.

	colors is an array of num_points * 3 float values to be filled with the
	colors read from the color grid.
*/
DL_INTERFACE bool DlVDBColorLookup(
	const char *filename,
	const char *colorgrid,
	size_t num_points,
	const float *points,
	float *colors);

/*
	This returns a representative subset of the points in a VDB points grid.

	ratio controls the % of source points to return (1.0 for all points).
	max_points is an upper bound on the number of points to return.
	*num_points is set to the number of generated points
	*points is set to an array of *num_points * 3 float values, with
	x0,y0,z0,x1,y1,z1, etc.
	*colors is set to a similar array with point colors, if colors is not null
	on input.

	Use DlVDBFreePoints(*points) to free the returned array. colors will be
	freed at the same time.
*/
DL_INTERFACE void DlVDBPointsSample(
	const char *filename,
	const char *gridname,
	double ratio,
	size_t max_points,
	size_t *num_points,
	const float **points,
	const float **colors);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
struct DlVDBGridInfo
{
	struct Info
	{
		const char *name;
		const char *value_type;
		int is_level_set;
		int is_points;
	};
	size_t num_grids;
	const Info *const *info;
};

extern "C"
{
DL_INTERFACE const DlVDBGridInfo* DlVDBGetGridInfo(
	const char *filename);

DL_INTERFACE void DlVDBFreeGridInfo(
	const DlVDBGridInfo *gridinfo);
}
#endif

#endif
